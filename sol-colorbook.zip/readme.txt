=== SOL SVG Coloring Book ===
Tags: svg, coloring book, color book, coloring pages
Tested up to: 4.1.1

A simple [colorbook] shortcode added to a page instantly displays this coloring book application to your website. On the admin side of things upload your own SVG files for kids to color online, or to print and color on their own.

== Description ==
Upload your own SVG files and you will have them instantly up and running for kids to color online, or print and color on their own. Simply add the [colorbook] shortcode to any page and the application displays your SVG files where they can be colored in marker, pencil, paintbrush, and crayon styles.

== Screenshots ==
1. On the front you will have 3 default svg images preloaded
2. You can edit/add/delete more SVGs on the admin side

== Upgrade Notice ==
Upgrade version allows the logo to be replaced and have a link tied to it.
=== SOL SVG Coloring Book ===
Contributors: crakrs
Tags: svg, coloring book, color book, coloring pages
Requires at least: 4.1.1
Tested up to: 4.1.1
Stable tag: trunk
License: Copyright 2015 SOL Emporium 

A simple [colorbook] shortcode added to a page displays the coloring book. On admin side upload your own SVG files for kids to color online.

== Description ==
Upload your own SVG files and you will have them instantly up and running for kids to color online, or print and color on their own. Simply add the [colorbook] shortcode to any page and the application displays your SVG files where they can be colored in marker, pencil, paintbrush, and crayon styles.

== Installation ==
Download and install from http://plugins.svn.wordpress.org/sol-coloring-book, either compressed zip or from uncompressed. Copy the sol-colorbook folder to the plugins directory on your site. Once installed, activate, and then follow the instructions given in admin on the SOL Coloring Book tab.

== Screenshots ==
1. An uncolored coloring book page
2. The admin screen for adding new svg coloring book pages
3. A colored coloring book page